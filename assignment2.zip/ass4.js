let object1=[{name:"manasa",age:10,country:"India",hobbies:["reading","cycling","baking"]},
{name:"preeya",age:20,country:"Singapore",hobbies:["reading","cycling","baking"]},
{name:"subb",age:50,country:"USA",hobbies:["reading","cycling","baking"]}];

function display(){
	
	
		if(object1[0].age < 30)
		{
			console.log(object1[0]);
			
		}
		if(object1[1].age < 30)
		{
			console.log(object1[1]);
			
		}
		if(object1[2].age < 30)
		{
			console.log(object1[2]);
			
		}

	
	
}
display();

console.log("----------------");

function displayb(){

	if(object1[0].country=="India")
	{
		console.log(object1[0]);
	}
	if(object1[1].country=="India")
	{
		console.log(object1[1]);
	}
	if(object1[2].country=="India")
	{
		console.log(object1[2]);
	}
}
displayb();