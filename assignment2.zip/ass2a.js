function change1(){
	const im=document.getElementById("img1");
	const newUrl="https://images.pexels.com/photos/1151282/pexels-photo-1151282.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500";
	im.src=newUrl;

}
function change0(){
	const im1=document.getElementById("img1");
	const newUrl1="https://images.pexels.com/photos/189349/pexels-photo-189349.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500";
	im1.src=newUrl1;

}
function change2(){
	const im2=document.getElementById("img1");
	const newUrl2="https://images.pexels.com/photos/1680140/pexels-photo-1680140.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500";
	im2.src=newUrl2;

}