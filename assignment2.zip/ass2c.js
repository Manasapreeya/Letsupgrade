let object1=[{name:"manasa",age:10,country:"India",hobbies:["reading","cycling","baking"]},
{name:"manasa",age:10,country:"India",hobbies:["reading","cycling","baking"]},
{name:"manasa",age:10,country:"India",hobbies:["reading","cycling","baking"]}];

function display(){
	console.log(object1);
}
display();
