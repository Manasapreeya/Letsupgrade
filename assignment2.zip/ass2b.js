function getvalue() {
	var a=document.getElementsByClassName("texta");
	var b=a[0].value;

	var c=document.getElementById("textb");
	let text=c.innerHTML;
	c.value=b;
}